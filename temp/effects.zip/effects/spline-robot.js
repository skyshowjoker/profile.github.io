/**
 * Spline Robot — 3D Spline Scene Loader
 * ======================================
 * Dynamically loads the Spline Viewer web component and injects a 3D scene
 * into any container element. Keeps @splinetool/viewer off the critical path
 * until explicitly requested.
 *
 * Usage:
 *   import { loadSplineViewer, createSplineViewer } from '/static/spline-robot.js';
 *
 *   await loadSplineViewer();
 *   createSplineViewer(
 *     'https://prod.spline.design/kZDDjO5HuC9GJUM2/scene.splinecode',
 *     'w-full h-full',
 *     '#my-container'
 *   );
 *
 * Dependencies: none (loads @splinetool/viewer from CDN on demand)
 */

const SPLINE_CDN_URL = 'https://unpkg.com/@splinetool/viewer@1.9.54/build/spline-viewer.js';

let _loaded = false;
let _loading = null;

/**
 * Ensures the Spline Viewer web component script is loaded.
 * Idempotent — safe to call multiple times; returns the same promise.
 * @returns {Promise<void>}
 */
export function loadSplineViewer() {
    if (_loaded) return Promise.resolve();
    if (_loading) return _loading;

    _loading = new Promise((resolve, reject) => {
        // Check if already in DOM (manual script tag)
        if (document.querySelector('script[src*="@splinetool/viewer"]')) {
            if (customElements.get('spline-viewer')) {
                _loaded = true;
                resolve();
                return;
            }
            // Tag exists but not yet defined — poll briefly
            customElements.whenDefined('spline-viewer').then(() => {
                _loaded = true;
                resolve();
            });
            return;
        }

        const script = document.createElement('script');
        script.type = 'module';
        script.src = SPLINE_CDN_URL;
        script.onload = () => {
            customElements.whenDefined('spline-viewer').then(() => {
                _loaded = true;
                resolve();
            });
        };
        script.onerror = () => {
            _loading = null;
            reject(new Error('Failed to load Spline Viewer from CDN'));
        };
        document.head.appendChild(script);
    });

    return _loading;
}

/**
 * Creates a <spline-viewer> element inside the given container.
 * Call after `await loadSplineViewer()`.
 *
 * @param {string}  sceneUrl  — Spline scene .splinecode URL
 * @param {string}  className — CSS classes for the <spline-viewer> element (e.g. "w-full h-[130%]")
 * @param {string}  containerSelector — CSS selector for the target container (default: inserts into body)
 * @returns {HTMLElement} The created <spline-viewer> element
 */
export function createSplineViewer(sceneUrl, className, containerSelector) {
    const container = document.querySelector(containerSelector);
    if (!container) {
        throw new Error(`Spline container not found: ${containerSelector}`);
    }

    const viewer = document.createElement('spline-viewer');
    viewer.setAttribute('url', sceneUrl);
    viewer.className = className || '';
    container.appendChild(viewer);
    return viewer;
}
