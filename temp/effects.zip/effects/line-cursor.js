/**
 * Line Cursor — Spring-Physics Cursor Trail
 * ==========================================
 * Replaces the native mouse cursor with a sleek glowing dot and
 * spring-physics-driven trailing lines rendered on a full-screen Canvas.
 *
 * Usage:
 *   <link rel="stylesheet" href="/static/line-cursor.css">
 *   <script type="module">
 *     import { initLineCursor, destroyLineCursor } from '/static/line-cursor.js';
 *     initLineCursor({ trails: 12, lightness: 50 });
 *     // ... later, to clean up:
 *     // destroyLineCursor();
 *   </script>
 *
 * Dependencies: line-cursor.css (for .cursor-dot styles and body cursor hiding)
 */

// ── Wave: drives HSL lightness oscillation ──────────────────────────
class Wave {
    constructor({ phase = 0, offset = 0, frequency = 0.001, amplitude = 1 } = {}) {
        this.phase = phase;
        this.offset = offset;
        this.frequency = frequency;
        this.amplitude = amplitude;
        this.value = 0;
    }

    update() {
        this.phase += this.frequency;
        this.value = this.offset + Math.sin(this.phase) * this.amplitude;
        return this.value;
    }
}

// ── Node: a single point in the spring chain ────────────────────────
class Node {
    constructor() {
        this.x = 0;
        this.y = 0;
        this.vx = 0;
        this.vy = 0;
    }
}

// ── Line: a chain of nodes with spring physics ──────────────────────
class Line {
    constructor(spring, opts) {
        this.spring = spring + 0.1 * Math.random() - 0.02;
        this.friction = opts.friction + 0.01 * Math.random() - 0.002;
        this.nodes = [];
        for (let i = 0; i < opts.nodeCount; i++) {
            const n = new Node();
            n.x = opts.pos.x;
            n.y = opts.pos.y;
            this.nodes.push(n);
        }
    }

    update(pos, opts) {
        let e = this.spring;
        let t = this.nodes[0];
        t.vx += (pos.x - t.x) * e;
        t.vy += (pos.y - t.y) * e;

        for (let i = 0; i < this.nodes.length; i++) {
            t = this.nodes[i];
            if (i > 0) {
                const n = this.nodes[i - 1];
                t.vx += (n.x - t.x) * e;
                t.vy += (n.y - t.y) * e;
                t.vx += n.vx * opts.dampening;
                t.vy += n.vy * opts.dampening;
            }
            t.vx *= this.friction;
            t.vy *= this.friction;
            t.x += t.vx;
            t.y += t.vy;
            e *= opts.tension;
        }
    }

    draw(ctx) {
        let n = this.nodes[0].x;
        let i = this.nodes[0].y;
        ctx.beginPath();
        ctx.moveTo(n, i);
        for (let a = 1; a < this.nodes.length - 2; a++) {
            const e = this.nodes[a];
            const t = this.nodes[a + 1];
            n = 0.5 * (e.x + t.x);
            i = 0.5 * (e.y + t.y);
            ctx.quadraticCurveTo(e.x, e.y, n, i);
        }
        const e = this.nodes[this.nodes.length - 2];
        const t = this.nodes[this.nodes.length - 1];
        ctx.quadraticCurveTo(e.x, e.y, t.x, t.y);
        ctx.stroke();
        ctx.closePath();
    }
}

// ── Default configuration ───────────────────────────────────────────
const DEFAULTS = {
    trails: 12,
    nodeCount: 30,
    friction: 0.5,
    dampening: 0.25,
    tension: 0.98,
    hue: 0,
    saturation: 0,
    lightness: 50,
    lightnessRange: 30,
    targetFPS: 60,
};

// ── Internal state ──────────────────────────────────────────────────
let _state = null; // { dot, canvas, ctx, pos, lines, wave, running, rafId, ... }

/**
 * Initializes the line cursor effect. Safe to call multiple times —
 * subsequent calls are ignored until destroyLineCursor() is called.
 *
 * @param {Object} [options] — optional overrides for DEFAULTS
 * @returns {{ destroy: Function }} handle with a destroy() method
 */
export function initLineCursor(options = {}) {
    if (_state) return { destroy: destroyLineCursor };

    const opts = { ...DEFAULTS, ...options };
    const pos = { x: 0, y: 0 };

    // ── Create DOM elements ─────────────────────────────────────────
    const dot = document.createElement('div');
    dot.className = 'cursor-dot';
    dot.id = 'cursorDot';
    document.body.appendChild(dot);

    const canvas = document.createElement('canvas');
    canvas.id = 'cursorCanvas';
    Object.assign(canvas.style, {
        position: 'fixed',
        inset: '0',
        pointerEvents: 'none',
        zIndex: '9996',
    });
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');

    // ── Create lines ────────────────────────────────────────────────
    const lines = [];
    for (let i = 0; i < opts.trails; i++) {
        lines.push(new Line(0.4 + (i / opts.trails) * 0.025, { ...opts, pos }));
    }

    // ── Wave for color oscillation ──────────────────────────────────
    const wave = new Wave({
        phase: Math.random() * 2 * Math.PI,
        amplitude: opts.lightnessRange,
        frequency: 0.0015,
        offset: opts.lightness,
    });

    // ── Render loop ─────────────────────────────────────────────────
    let lastTime = 0;
    const frameInterval = 1000 / opts.targetFPS;

    function render(currentTime) {
        if (!_state) return;
        _state.rafId = requestAnimationFrame(render);

        const deltaTime = currentTime - lastTime;
        if (deltaTime < frameInterval) return;
        lastTime = currentTime - (deltaTime % frameInterval);

        ctx.globalCompositeOperation = 'source-over';
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.globalCompositeOperation = 'lighter';

        const lightness = opts.lightness + Math.sin(wave.update() * 0.01) * opts.lightnessRange;
        ctx.strokeStyle = `hsla(${opts.hue}, ${opts.saturation}%, ${lightness}%, 0.15)`;
        ctx.lineWidth = 1;

        for (let i = 0; i < opts.trails; i++) {
            lines[i].update(pos, opts);
            lines[i].draw(ctx);
        }
    }

    // ── Event handlers ──────────────────────────────────────────────
    function onMove(e) {
        if (e.touches) {
            pos.x = e.touches[0].pageX;
            pos.y = e.touches[0].pageY;
        } else {
            pos.x = e.clientX;
            pos.y = e.clientY;
        }
        dot.style.left = pos.x + 'px';
        dot.style.top = pos.y + 'px';
    }

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    // ── Bootstrap ───────────────────────────────────────────────────
    resize();
    document.addEventListener('mousemove', onMove);
    document.addEventListener('touchmove', onMove);
    window.addEventListener('resize', resize);

    _state = {
        dot,
        canvas,
        ctx,
        pos,
        lines,
        wave,
        running: true,
        rafId: requestAnimationFrame(render),
        opts,
        handlers: { onMove, resize },
    };

    return { destroy: destroyLineCursor };
}

/**
 * Removes the line cursor effect and restores the native cursor.
 * Safe to call even if the cursor was never initialized.
 */
export function destroyLineCursor() {
    if (!_state) return;

    cancelAnimationFrame(_state.rafId);
    document.removeEventListener('mousemove', _state.handlers.onMove);
    document.removeEventListener('touchmove', _state.handlers.onMove);
    window.removeEventListener('resize', _state.handlers.resize);

    if (_state.dot && _state.dot.parentNode) {
        _state.dot.parentNode.removeChild(_state.dot);
    }
    if (_state.canvas && _state.canvas.parentNode) {
        _state.canvas.parentNode.removeChild(_state.canvas);
    }

    _state = null;
}
